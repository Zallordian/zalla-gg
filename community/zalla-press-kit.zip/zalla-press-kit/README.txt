Zalla press kit
===============

Zalla is a private, local-first web browser for iPhone, made by Kurt Paris.
Built around you. Private by default. Beautiful by design.

Website: https://zalla.gg
Press contact: ZallaBrowser@pm.me
Requires iOS 17 or later. Free, with an optional one-time Zalla Unlock.

What is in here
- logos/zalla-icon-1024.png, -512.png, -256.png: the app icon
- logos/zalla-z-transparent-1024.png: the Z swoosh on a transparent background
- logos/zalla-lockup-on-dark.png: icon and wordmark for dark backgrounds
- logos/zalla-lockup-on-light.png: icon and wordmark for light backgrounds
- screenshots/app-store-slides: the eight App Store screenshots (1284 x 2778)
- screenshots/raw-captures: plain captures from the app, without captions
- text/short-description.txt and text/long-description.txt
- colors.txt

Using the logo
- Please use the files as they are. Do not recolor, stretch, rotate or add effects to the icon or the Z.
- Give the logo some room. Keep clear space around it of at least a quarter of the icon's width.
- Use the dark lockup on dark backgrounds and the light lockup on light ones.
- Zalla is written with a capital Z and lowercase "alla".
- Privacy Shield is not a VPN. Please do not describe Zalla as one.
